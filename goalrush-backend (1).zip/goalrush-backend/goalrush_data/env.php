<?php
// Ganti dengan teks acak panjang, dipakai SEKALI saat membuat kata sandi admin pertama kali.
return ['SETUP_KEY' => 'GANTI_DENGAN_TEKS_ACAK'];
