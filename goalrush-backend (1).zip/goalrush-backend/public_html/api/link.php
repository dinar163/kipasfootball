<?php
require __DIR__ . '/_lib.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error'=>'Metode tidak diizinkan'], 405);
if (!ratelimit('link' . client_ip(), 30, 60)) out(['error'=>'Terlalu banyak permintaan'], 429);
$in = json_decode(file_get_contents('php://input'), true);
$p = verify($in['token'] ?? '');
if (!$p || !isset($p['n'])) out(['error'=>'Sesi tidak valid'], 401);
if (empty($p['v'])) $p['v'] = microtime(true);
out(['token' => sign($p)]);
