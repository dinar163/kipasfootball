<?php
require __DIR__ . '/_lib.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error'=>'Metode tidak diizinkan'], 405);
if (!ratelimit('step' . client_ip(), 60, 60)) out(['error'=>'Terlalu banyak permintaan'], 429);
$in = json_decode(file_get_contents('php://input'), true);
$p = verify($in['token'] ?? '');
if (!$p || !isset($p['n'])) out(['error'=>'Sesi tidak valid, muat ulang halaman'], 401);
$c = cfg();
if ($c['apk_file'] === '' && $c['apk_url'] === '') out(['error'=>'File belum tersedia'], 503);
if (microtime(true) - $p['t'] < (float)$c['waitSec'] - 0.4) out(['error'=>'Terlalu cepat, tunggu sebentar'], 429);
if ($c['verify_url'] !== '' && $p['n'] == 0 && (empty($p['v']) || microtime(true) - $p['v'] < (float)$c['verifyWait'] - 1)) out(['error'=>'Selesaikan verifikasi link dulu'], 403);
$n = $p['n'] + 1;
if ($n >= (int)$c['clicks']) {
    $dl = sign(['dl'=>1, 'exp'=>time()+300, 'k'=>bin2hex(random_bytes(6))]);
    out(['n'=>$n, 'download'=>'api/download.php?t=' . $dl]);
}
out(['n'=>$n, 'token'=>sign(['n'=>$n, 't'=>microtime(true), 'exp'=>time()+1800, 'k'=>$p['k'] ?? ''])]);
