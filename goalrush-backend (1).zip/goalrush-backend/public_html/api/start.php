<?php
require __DIR__ . '/_lib.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['error'=>'Metode tidak diizinkan'], 405);
if (!ratelimit('start' . client_ip(), 30, 60)) out(['error'=>'Terlalu banyak permintaan'], 429);
out(['token' => sign(['n'=>0, 't'=>microtime(true), 'exp'=>time()+1800, 'k'=>bin2hex(random_bytes(6))])]);
