<?php
// Folder data: pakai ../goalrush_data (di luar public_html) bila ada, kalau tidak pakai ./data
$__outside = dirname(__DIR__, 2) . '/goalrush_data';
define('DATA', is_dir($__outside) ? $__outside : dirname(__DIR__) . '/data');
if (!is_dir(DATA)) { @mkdir(DATA, 0700, true); }
if (!is_dir(DATA . '/apk')) { @mkdir(DATA . '/apk', 0700, true); }

function cfg() {
    $f = DATA . '/config.json';
    $d = is_file($f) ? json_decode(file_get_contents($f), true) : [];
    return array_merge(['version'=>'Terbaru','tg'=>'','notice'=>'','clicks'=>5,'waitSec'=>2,'faq'=>[],'apk_file'=>'','apk_url'=>'','verify_url'=>'','update_note'=>'','verify_label'=>'Buka link verifikasi','verifyWait'=>10], is_array($d) ? $d : []);
}
function secret() {
    $f = DATA . '/secret.key';
    if (!is_file($f)) { file_put_contents($f, bin2hex(random_bytes(32))); @chmod($f, 0600); }
    return trim(file_get_contents($f));
}
function b64u($s) { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function sign($p) { $j = b64u(json_encode($p)); return $j . '.' . hash_hmac('sha256', $j, secret()); }
function verify($t) {
    if (!is_string($t) || substr_count($t, '.') !== 1) return null;
    [$j, $m] = explode('.', $t);
    if (!hash_equals(hash_hmac('sha256', $j, secret()), $m)) return null;
    $p = json_decode(base64_decode(strtr($j, '-_', '+/')), true);
    if (!is_array($p) || ($p['exp'] ?? 0) < time()) return null;
    return $p;
}
function out($d, $c = 200) {
    http_response_code($c);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($d); exit;
}
function client_ip() { return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }
// true = masih boleh, false = kena batas
function ratelimit($key, $max, $win) {
    $d = DATA . '/rl'; if (!is_dir($d)) @mkdir($d, 0700, true);
    $fp = fopen($d . '/' . sha1($key) . '.json', 'c+'); flock($fp, LOCK_EX);
    $r = json_decode(stream_get_contents($fp), true); $now = time();
    if (!$r || $now - $r['s'] > $win) $r = ['s' => $now, 'c' => 0];
    $r['c']++; ftruncate($fp, 0); rewind($fp); fwrite($fp, json_encode($r));
    flock($fp, LOCK_UN); fclose($fp);
    return $r['c'] <= $max;
}
