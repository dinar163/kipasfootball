<?php
require __DIR__ . '/_lib.php';
$p = verify($_GET['t'] ?? '');
if (!$p || empty($p['dl'])) { http_response_code(403); exit('Link tidak valid atau sudah kedaluwarsa. Ulangi verifikasi.'); }
if (!ratelimit('dl' . client_ip(), 10, 600)) { http_response_code(429); exit('Terlalu banyak unduhan, coba lagi nanti.'); }
$c = cfg();
if ($c['apk_file'] !== '') {
    $path = DATA . '/apk/' . basename($c['apk_file']);
    if (!is_file($path)) { http_response_code(404); exit('File tidak ditemukan.'); }
    header('Content-Type: application/vnd.android.package-archive');
    header('Content-Disposition: attachment; filename="GOALRUSH_FOOTBALL.apk"');
    header('Content-Length: ' . filesize($path));
    header('X-Content-Type-Options: nosniff'); header('Cache-Control: no-store');
    while (ob_get_level()) ob_end_clean();
    readfile($path); exit;
}
if (preg_match('#^https://#', $c['apk_url'])) { header('Cache-Control: no-store'); header('Location: ' . $c['apk_url'], true, 302); exit; }
http_response_code(404); exit('File belum tersedia.');
