<?php
require __DIR__ . '/_lib.php';
$c = cfg();
out(['version'=>$c['version'],'tg'=>$c['tg'],'notice'=>$c['notice'],'clicks'=>(int)$c['clicks'],'waitSec'=>(float)$c['waitSec'],'faq'=>$c['faq'],'updateNote'=>$c['update_note'],'verifyUrl'=>$c['verify_url'],'verifyLabel'=>$c['verify_label'],'verifyWait'=>(float)$c['verifyWait'],'ready'=>($c['apk_file'] !== '' || $c['apk_url'] !== '')]);
