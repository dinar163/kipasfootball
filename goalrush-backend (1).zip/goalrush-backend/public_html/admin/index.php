<?php
require __DIR__ . '/../api/_lib.php';
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS']),'httponly'=>true,'samesite'=>'Strict']);
session_name('gr_admin'); session_start();
header('X-Frame-Options: DENY'); header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: no-referrer'); header('Cache-Control: no-store');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'");
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function parse_faq($s) { $o = []; foreach (preg_split('/\R\s*\R/', trim($s)) as $b) { if (preg_match('/^Q:\s*(.+?)\R+A:\s*(.+)$/s', trim($b), $m)) $o[] = ['q'=>trim($m[1]), 'a'=>trim($m[2])]; } return array_slice($o, 0, 30); }
function faq_text($f) { $t = ''; foreach ($f as $x) $t .= "Q: {$x['q']}\nA: {$x['a']}\n\n"; return trim($t); }
function num($v, $a, $b, $d) { $x = is_numeric($v) ? (float)$v : $d; return max($a, min($b, $x)); }
function https_or_empty($u) { $u = trim($u); return ($u === '' || preg_match('#^https://[^\s<>"\']+$#', $u)) ? $u : false; }

$adminFile = DATA . '/admin.json'; $envFile = DATA . '/env.php'; $msg = ''; $ok = '';
$env = is_file($envFile) ? (include $envFile) : [];
$post = $_SERVER['REQUEST_METHOD'] === 'POST';
$act = $post ? ($_POST['act'] ?? '') : '';

if (!is_file($adminFile)) {                       // ===== SETUP PERTAMA =====
    $key = $env['SETUP_KEY'] ?? '';
    if ($key === '' || $key === 'GANTI_DENGAN_TEKS_ACAK') { $msg = 'Isi SETUP_KEY di file env.php (folder data) lebih dulu.'; $setup = false; } else $setup = true;
    if ($setup && $act === 'setup') {
        if (!ratelimit('setup' . client_ip(), 5, 900)) $msg = 'Terlalu banyak percobaan.';
        elseif (!hash_equals($key, (string)($_POST['key'] ?? ''))) $msg = 'Setup key salah.';
        elseif (strlen($_POST['pw'] ?? '') < 12) $msg = 'Kata sandi minimal 12 karakter.';
        else { file_put_contents($adminFile, json_encode(['hash'=>password_hash($_POST['pw'], PASSWORD_DEFAULT)])); @chmod($adminFile, 0600); $ok = 'Kata sandi dibuat. Silakan masuk.'; header('Refresh: 1'); }
    }
    echo '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Setup admin</title>';
    echo '<style>body{font:16px system-ui;max-width:420px;margin:60px auto;padding:0 20px}input,button{width:100%;padding:12px;margin:6px 0;font:inherit}.e{color:#c22}.k{color:#080}</style><h2>Setup admin</h2>';
    if ($msg) echo '<p class=e>' . h($msg) . '</p>'; if ($ok) echo '<p class=k>' . h($ok) . '</p>';
    if ($setup && !$ok) echo '<form method=post><input type=hidden name=act value=setup><input name=key placeholder="Setup key (dari env.php)" required><input type=password name=pw placeholder="Kata sandi baru (min 12 karakter)" required><button>Buat kata sandi</button></form>';
    exit;
}
$admin = json_decode(file_get_contents($adminFile), true);

if ($act === 'login') {
    if (!ratelimit('login' . client_ip(), 5, 900)) $msg = 'Terlalu banyak percobaan. Coba lagi 15 menit lagi.';
    elseif (password_verify($_POST['pw'] ?? '', $admin['hash'] ?? '')) { session_regenerate_id(true); $_SESSION['in'] = 1; header('Location: ./'); exit; }
    else $msg = 'Kata sandi salah.';
}
if ($act === 'logout' && hash_equals(csrf(), $_POST['csrf'] ?? '')) { $_SESSION = []; session_destroy(); header('Location: ./'); exit; }

$in = !empty($_SESSION['in']);
if ($in && $act === 'save') {
    if (!hash_equals(csrf(), $_POST['csrf'] ?? '')) { $msg = 'Sesi kedaluwarsa, muat ulang.'; }
    else {
        $c = cfg(); $tg = https_or_empty($_POST['tg'] ?? ''); $url = https_or_empty($_POST['apk_url'] ?? ''); $vu = https_or_empty($_POST['verify_url'] ?? '');
        if ($tg === false || $url === false || $vu === false) $msg = 'Link harus diawali https://';
        else {
            $c['version'] = mb_substr(trim($_POST['version'] ?? ''), 0, 30); $c['tg'] = $tg; $c['apk_url'] = $url;
            $c['notice'] = mb_substr(trim($_POST['notice'] ?? ''), 0, 200);
            $c['clicks'] = (int)round(num($_POST['clicks'] ?? 5, 1, 20, 5)); $c['waitSec'] = num($_POST['waitSec'] ?? 2, 0, 30, 2);
            $c['faq'] = parse_faq($_POST['faq'] ?? ''); $c['update_note'] = mb_substr(trim($_POST['update_note'] ?? ''), 0, 120); $c['verify_url'] = $vu; $c['verify_label'] = mb_substr(trim($_POST['verify_label'] ?? ''), 0, 40) ?: 'Buka link verifikasi'; $c['verifyWait'] = num($_POST['verifyWait'] ?? 10, 0, 120, 10);
            if (!empty($_FILES['apk']['name']) && $_FILES['apk']['error'] === UPLOAD_ERR_OK) {
                $f = $_FILES['apk'];
                if (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'apk') $msg = 'File harus berekstensi .apk';
                elseif ($f['size'] > 600 * 1024 * 1024) $msg = 'File terlalu besar (maks 600 MB).';
                elseif (file_get_contents($f['tmp_name'], false, null, 0, 2) !== 'PK') $msg = 'File bukan APK yang valid.';
                else { $name = 'game-' . date('Ymd-His') . '.apk'; if (move_uploaded_file($f['tmp_name'], DATA . '/apk/' . $name)) { if ($c['apk_file'] !== '') @unlink(DATA . '/apk/' . basename($c['apk_file'])); $c['apk_file'] = $name; } else $msg = 'Gagal menyimpan file.'; }
            } elseif (!empty($_FILES['apk']['name'])) $msg = 'Upload gagal (cek batas upload_max_filesize di hosting).';
            if ($msg === '') { file_put_contents(DATA . '/config.json', json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX); $ok = 'Tersimpan dan langsung aktif di website.'; }
        }
    }
}
echo '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Admin GOALRUSH</title>';
echo '<style>body{font:16px system-ui;background:#f3f6f4;margin:0}main{max-width:720px;margin:auto;padding:24px}.c{background:#fff;border-radius:16px;padding:22px;margin-bottom:16px}label{display:block;font-size:13px;color:#566;margin:14px 0 4px}input,textarea{width:100%;padding:11px;border:1px solid #cfd8d2;border-radius:10px;font:inherit;box-sizing:border-box}button{padding:12px 22px;border:0;border-radius:99px;background:#08a62a;color:#fff;font:600 16px system-ui;cursor:pointer}.g{display:grid;grid-template-columns:1fr 1fr;gap:12px}.e{color:#c22}.k{color:#080}small{color:#566}</style><main>';
if (!$in) {
    echo '<div class=c><h2>Masuk admin</h2>'; if ($msg) echo '<p class=e>' . h($msg) . '</p>';
    echo '<form method=post><input type=hidden name=act value=login><input type=password name=pw placeholder="Kata sandi" required autofocus><p><button>Masuk</button></p></form></div></main>'; exit;
}
$c = cfg();
echo '<div class=c><h2>Panel admin GOALRUSH</h2>'; if ($msg) echo '<p class=e>' . h($msg) . '</p>'; if ($ok) echo '<p class=k>' . h($ok) . '</p>';
echo '<p><small>File APK saat ini: ' . h($c['apk_file'] ?: ($c['apk_url'] ? 'link eksternal' : 'belum ada')) . '</small></p>';
echo '<form method=post enctype="multipart/form-data"><input type=hidden name=act value=save><input type=hidden name=csrf value="' . h(csrf()) . '">';
echo '<label>Upload APK baru (disimpan di server, tidak pernah ditampilkan ke publik)</label><input type=file name=apk accept=".apk">';
echo '<label>atau link APK eksternal (https), dipakai bila tidak ada file upload</label><input name=apk_url value="' . h($c['apk_url']) . '">';
echo '<div class=g><div><label>Versi</label><input name=version value="' . h($c['version']) . '"></div><div><label>Link Telegram</label><input name=tg value="' . h($c['tg']) . '"></div>';
echo '<div><label>Jumlah klik verifikasi (1-20)</label><input type=number name=clicks min=1 max=20 value="' . (int)$c['clicks'] . '"></div><div><label>Tunggu per klik, detik (0-30)</label><input type=number step=0.5 name=waitSec min=0 max=30 value="' . h($c['waitSec']) . '"></div></div>';
echo '<label>Pengumuman (kosong = sembunyikan)</label><input name=notice value="' . h($c['notice']) . '">';
echo '<label>Catatan update (tampil di banner untuk pengunjung yang memakai versi lama, maks 120 karakter)</label><input name=update_note maxlength=120 value="' . h($c['update_note']) . '">';
echo '<label>Link verifikasi (https, kosongkan untuk menonaktifkan). Pengunjung wajib membukanya dulu sebelum klik download</label><input name=verify_url value="' . h($c['verify_url']) . '"><div class=g><div><label>Teks tombol verifikasi</label><input name=verify_label value="' . h($c['verify_label']) . '"></div><div><label>Waktu tunggu setelah membuka link, detik (0-120)</label><input type=number name=verifyWait min=0 max=120 value="' . h($c['verifyWait']) . '"></div></div>';
echo '<label>FAQ (format: baris Q: pertanyaan, baris A: jawaban, pisahkan tiap item dengan baris kosong)</label><textarea name=faq rows=10>' . h(faq_text($c['faq'])) . '</textarea>';
echo '<p><button>Simpan &amp; publikasikan</button></p></form>';
echo '<form method=post><input type=hidden name=act value=logout><input type=hidden name=csrf value="' . h(csrf()) . '"><button style="background:#555">Keluar</button></form></div></main>';
