# GOALRUSH – paket backend (PHP 8+)

Cocok untuk hosting cPanel biasa maupun VPS. Tidak perlu database.

## Struktur
- `public_html/`  → isi folder ini di-upload ke public_html domain .my.id
- `goalrush_data/` → upload ke SATU TINGKAT DI ATAS public_html (di luar folder web). Isinya: config, kunci rahasia, file APK.

## Pemasangan
1. Upload isi `public_html/` ke `public_html/` hosting kamu.
2. Upload folder `goalrush_data/` ke folder di atas `public_html/` (sejajar, bukan di dalamnya).
   Kalau terpaksa di dalam public_html, ganti namanya menjadi `data` dan pastikan `.htaccess`-nya ikut terupload.
3. Edit `goalrush_data/env.php`: ganti `SETUP_KEY` dengan teks acak panjang.
4. Buka `https://domainmu.my.id/admin/` → isi Setup key dan buat kata sandi (min 12 karakter).
5. Masuk, upload APK, isi pengaturan, klik Simpan & publikasikan.
6. Pastikan versi PHP 8.0+ (cPanel → Select PHP Version).

## Cek keamanan (wajib)
- `https://domainmu.my.id/data/config.json` dan `/goalrush_data/` harus 403/404.
- Buka halaman, selesaikan klik verifikasi, dan pastikan link `api/download.php?t=...` berhenti bekerja setelah ±5 menit.
- Coba panggil `api/download.php` tanpa token → harus ditolak (403).
- Setelah admin dibuat, hapus `SETUP_KEY` dari env.php (kosongkan).

## Cara kerja verifikasi
- Browser memanggil `start.php` → token bertanda tangan (HMAC).
- Tiap klik memanggil `step.php`; server menolak bila jeda kurang dari `waitSec`.
- Setelah `clicks` langkah, server memberi link `download.php?t=...` berlaku 5 menit. File APK disimpan di luar folder web dan dikirim lewat PHP.

## Catatan
- Jika memakai Cloudflare, rate limit membaca IP dari `REMOTE_ADDR`; atur mod_remoteip / restore IP di hosting agar IP pengunjung asli terbaca.
- Hanya bagikan APK dan konten yang kamu punya hak untuk mendistribusikannya.
- Pastikan `upload_max_filesize` hosting cukup besar untuk APK-mu; kalau tidak, pakai "link APK eksternal".

## Admin dan website di domain berbeda (satu akun hosting)
Contoh: website `goalrush.my.id`, admin `admin.goalrush.my.id` (atau domain lain yang kamu miliki).
1. Di cPanel: Domains (atau Subdomains) → buat `admin.goalrush.my.id`, lalu atur **Document Root** ke folder `public_html/admin`.
   Untuk domain yang benar-benar berbeda, tambahkan sebagai Addon/Alias Domain dengan Document Root yang sama (`public_html/admin`).
2. Aktifkan SSL untuk kedua domain.
3. Jangan pindahkan file: admin dan website tetap membaca `goalrush_data/` yang sama di server, jadi perubahan langsung terhubung tanpa CORS atau API tambahan.
4. `.htaccess` sudah menolak akses `/admin/` lewat domain utama (404). Kalau host admin tidak diawali `admin.`, ubah baris `RewriteCond %{HTTP_HOST} !^admin\.`.
5. Tes: `https://goalrush.my.id/admin/` harus 404, `https://admin.goalrush.my.id/` menampilkan login.
Catatan: cara ini hanya jalan bila KEDUA domain berada di akun hosting yang sama. Untuk server berbeda, diperlukan API admin terotentikasi tambahan.
